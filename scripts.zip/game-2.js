
var x = 0;
var m = 1;
var timer_i = 0;
var o = 0;

setInterval(() => { 
   if (game.loadingScreenEnd == true) {
   if (train.door.on == true) {
      if (train.door.door_alert == true) {
         document.getElementById("T:DO").style.opacity = 0.65
         document.getElementById("T:DC").style.opacity = 0.65
      } else {
         document.getElementById("T:DO").style.opacity = 0.8
         document.getElementById("T:DC").style.opacity = 0.4
      }
   } else {
      document.getElementById("T:DO").style.opacity = 0.4
      document.getElementById("T:DC").style.opacity = 0.8
   }
   
   if (train.speed <= 0.8 && train.tension_up == false) {
      document.getElementById("T:S").style.opacity = 0.8
   } else {
      document.getElementById("T:S").style.opacity = 0.4
   }
   
   if (train.speed >= game.popup1.speed_limit + 4) {
      document.getElementById("T:SB").style.opacity = 0.8
   } else {
      document.getElementById("T:SB").style.opacity = 0.4
   }
   
   // train Y position ( not actually working now)
   
   if (train.speed >= 1) {
      x = 0;
   } else {
      x = 100;
   }
   //document.getElementById("train element").style.top = x + "px"
   
   // camera sytem
   
   if (game.camera == 1 && m == 1) {
      document.getElementById("2D train element").style.visibility = "hidden"

      document.getElementById("train element").style.visibility = "visible"
      document.getElementById("maps element").style.visibility = "visible"
      m = 0;
   }
   
   if (game.camera == 2 &&  m == 0) {
      document.getElementById("2D train element").style.visibility = "visible"

      document.getElementById("train element").style.visibility = "hidden"
      document.getElementById("maps element").style.visibility = "hidden"
      m = 1;
   }
   
   // timer mods
   
   if (train.in_station == true && timer_i == 0) {
      if (game.event.station[2]["timer+"] == true) {
         game.timer.disable = false;
      }
      if (game.event.station[2]["timer+"] == false) {
         game.timer.disable = true;
      } else {
         game.timer.A += game.event.station[2]["timer+"];
         document.getElementById("timer").innerText = "timer: "+game.timer.A;
      }
      timer_i = 1;
   }
   
   if (train.in_station == false && timer_i == 1) {
      timer_i = 0;
   }
   
   if (game.timer.disable == false && game.mode.timer == "true") {
      if (game.timer.A <= -1) {
         document.getElementById("timer").style.color = "#FF6C6C";
      } else if (game.timer.A <= 15) {
         document.getElementById("timer").style.color = "orange";
      } else {
         document.getElementById("timer").style.color = "#0000007D";
      }
   } else {
      document.getElementById("timer").style.color = "white";
   }
   
     
   
   if (o >= 730) {
      o = -730;
   } else {
      o += train.speed * 0.15;
   }
   if (game.camera == 2 && train.speed >= 1) {
      document.getElementById("D_BGT").style.left = o + "px";
   }
   
   if (game.camera == 2) {
      if (train.light.light_exterior == false) {
         document.getElementById("train2D 2").style.visibility = "visible";
         document.getElementById("train2D 1").style.visibility = "hidden";
      } else {
         document.getElementById("train2D 2").style.visibility = "hidden";
         document.getElementById("train2D 1").style.visibility = "visible";
      }
   } else {
      document.getElementById("train2D 2").style.visibility = "hidden";
      document.getElementById("train2D 1").style.visibility = "hidden";
   }
}},0)

var camera_i = 0;
function camera() { 
   if (game.loadingScreenEnd == true) {
      if (game.camera == 1) {
         game.camera = 2;
      } else {
         game.camera = 1;
      }
   }
}

setInterval(() => {
   if (train.moved == true) {
      game.timer.A--;
   
      if (game.timer.disable == true || game.mode.timer == "false") {
         document.getElementById("timer").innerText = "timer: ---";
      } else {
         document.getElementById("timer").innerText = "timer: "+game.timer.A;
      }
   }
   if (game.timer.disable == false && game.mode.timer == "true" && train.moved == false) {
      document.getElementById("timer").innerText = "timer: "+game.timer.A;
   }
},1150)

var i2 = 1;
function DNRhide() {
  if (i2 == 1) {
    i2 = 0;
    document.getElementById("DNR").style.left = "560px"
    document.getElementById("DNR").style.opacity = "0.4"

  } else {
    i2 = 1;
    document.getElementById("DNR").style.left = "460px"
    document.getElementById("DNR").style.opacity = "1"
  }
}

var i3 = 0;
function TAIS() {
  if (i3 == 1) {
    i3 = 0;
    //document.getElementById("Train avanced interior system").style.cssText = "top: 270px; opacity: 0.4;"
    document.getElementById("Train avanced interior system").style.top = "270px"
    document.getElementById("Train avanced interior system").style.opacity = "1"
  } else {
    i3 = 1;
    document.getElementById("Train avanced interior system").style.top = "363px"
    document.getElementById("Train avanced interior system").style.opacity = "0.7"
  }
}

var op = 0;
setInterval(() => {
   if (train.speed <= 3 && op <= 6) {
      op += 0.04;
      //console.log(op)
      document.getElementById("train element").style.top = op+"px";
   } else if (train.speed >= 1 && op >= 0) {
      op -= 0.04;
      document.getElementById("train element").style.top = op+"px";
   }
   
   if (i2 == 1) {
      if (train.moveSens == 1) {
         document.getElementById("DNR text").innerText = "Forward ↑";
      }
   
      if (train.moveSens == 0) {
         document.getElementById("DNR text").innerText = "Neutre –";
      }
   
      if (train.moveSens == -1) {
         document.getElementById("DNR text").innerText = "back ↓";
      }
   }
   
   if (train.door.on == true) {
      document.getElementById("G:DD").style.visibility = "visible";
   } else {
      document.getElementById("G:DD").style.visibility = "hidden";
   }
   
   if (train.light.light_exterior == true) {
      document.getElementById("G:L").style.visibility = "visible";
   } else {
      document.getElementById("G:L").style.visibility = "hidden";
   }
   
   document.getElementById("CurTime").innerText = new Date().getHours()+":"+new Date().getMinutes()+":"+new Date().getSeconds()
},0)

var speed = 0;
var turn2 = -70;
document.getElementById("SC:P1").style.transform = "rotate(" + turn2 * 2.2 + "deg)";
setInterval(() => {
  if (train.speed >= 1) {
    document.getElementById("SC:P1").style.transform = "rotate("+turn2 * 2.2+"deg)";
    turn2 = train.speed - 225;
  }
},0)