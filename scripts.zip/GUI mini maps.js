let json_map = "";
let selected = "null";
let train_json = null;
let refresh_time = 0;
let mtp_counter = null;
let mtp_speed = 0.09;
let disableTrain = localStorage.getItem('HTS setting disable mini train');
let i2 = 0;

map_json = "assets/Lignes/"+localStorage.getItem("ligne select")+".json";
train_Selecte2();

function train_Selecte2() {
    // get the json file
  var rawFile = new XMLHttpRequest();
  var reload = 0;
  rawFile.open("get",map_json, true);
  rawFile.onreadystatechange = function() {
    reload++;
    if (rawFile.readyState === 4) {
      var allText = rawFile.responseText;
    }
    if (reload == 3 ) {
      
      if (allText == "Error 404, file not found.") {
        alert("error ! | sorry no train asset found")
      } else {
        json_map = JSON.parse(allText);
        map_element()
        looop();
        other()
        makeTrainIngame(json_map.maps.trajet[json_map.maps.trajet.length - 1][2].distance / 2)
      }
    }
  }
  rawFile.send();
}

function map_element() {
  var Y = 0;
  var element = 0;
  var P = 0;
  var feux = {
    value: 0,
    spawn: 0
  }
  document.getElementById("train element").style.top = '100px'
  document.getElementById("bg").style.height = json_map.maps.trajet[json_map.maps.trajet.length - 1][2].distance+ 50 +'px'
  document.getElementById("bg2").style.height = json_map.maps.trajet[json_map.maps.trajet.length - 1][2].distance+ 50 +'px'
  
  for (var i = 0; i < json_map.maps.trajet[json_map.maps.trajet.length - 1][2].distance && json_map.maps.trajet.length - 1 >= element; i++) {
    var verifed = false;
    
    feux.value++;
    if (feux.value >= 1) {
      feux.value = 0;
      
      var f = document.createElement("img");
      document.getElementById('train element').appendChild(f);
      
      f.style.position = "absolute";
      f.style.left = "280px"
      f.style.scale = 0.15
      f.style.top = ""+ Y * 105+ "px";
      f.src = 'images/feux/XOO.png'
    }
    
    if (json_map.maps.trajet[element][2].distance >= Y) {
      var div = document.createElement("a");
      document.getElementById('train element').appendChild(div);
      div.style.position = "absolute";
      div.style.left = "300px"
      div.style.top = ""+ json_map.maps.trajet[element][2].distance + "px";
      div.innerText = json_map.maps.trajet[element][0];
      div.style.color = "white"
      verifed = true;
      // style
      
      if (div.innerText == "speed") {
        div.style.backgroundColor = "red";
        div.style.opacity = 0.5;
        div.style.left = "260px"
        div.style.color = "#00000000";
        
        var div2 = document.createElement("a");
        document.getElementById('train element').appendChild(div2);
        div2.style.position = "absolute";
        div2.innerText = json_map.maps.trajet[element][1];
        div2.style.scale = "0.6";
        div.style.scale = "0.7"

        var div3 = document.createElement("div");
        document.getElementById('train element').appendChild(div3);
        div3.style.backgroundColor = "red";
        div3.style.opacity = 0.5;
        div3.style.left = "260px"
        div3.style.width = "100px"
        div3.style.height = "100px"
        
      var div4 = document.createElement("div");
      document.getElementById('train element').appendChild(div4);
      div4.style.position = "absolute";
      div4.style.left = "266px"
      div4.style.top = ""+ json_map.maps.trajet[element][2].distance + "px";
      div4.innerText = "_______"
      div4.style.opacity = 0.5
      div4.style.zIndex = 1
      div4.style.color = "red"
      
      
        if (json_map.maps.trajet[element][2].pre_release == true) {
          div2.style.color = "orange"
        } else {
          div2.style.color = "white"
        }
        
        if (json_map.maps.trajet[element][2].hide == true) {
          div2.style.color = "#7A7A7A"
          div2.style.left = "270px"
        } else {
          div2.opacity = 0.5;
          div2.style.left = "270px"
        }
        
        div2.style.top = ""+ json_map.maps.trajet[element][2].distance + "px";
        
      }
      
      if (div.innerText == "station") {
        div.style.backgroundColor = "blue";
        div.style.zIndex = 1;
        div.style.height = "50px"
        div.style.width = "15px"
        div.innerText = "."
        div.style.color = "blue"
        div.style.left = "341px"
        div.style.borderRadius = "4px 4px 4px 4px";
        div.style.top = ""+ json_map.maps.trajet[element][2].distance - 55 + P + "px";
        
        verifed = true;
        
        var div2 = document.createElement("a");
        document.getElementById('train element').appendChild(div2);
        div2.style.position = "absolute";
        div2.style.left = "345px"
        div2.style.zIndex = "1"
        div2.style.color = "white"
        div2.style.backgroundColor = "#FFFFFF40"
        div2.style.top = ""+ json_map.maps.trajet[element][2].distance - 40 + P + "px";
        div2.innerText = json_map.maps.trajet[element][1];
        div2.style.scale = "0.5";
        div2.style.borderRadius = "4px 4px 4px 4px";
        
        var m = document.createElement("a");
        document.getElementById('train element').appendChild(m);
        m.style.position = "absolute";
        m.style.backgroundColor = "blue";
        m.style.zIndex = 1;
        m.style.color = "white"
        m.style.height = "50px"
        m.style.width = "15px"
        m.innerText = "."
        m.style.color = "blue"
        m.style.borderRadius = "4px 4px 4px 4px";
        m.style.left = "288.4px"
        m.style.top = ""+ json_map.maps.trajet[element][2].distance - 55 + P + "px";
  
      }
      
      if (div.innerText == "fake station") {
        div.style.backgroundColor = "darkblue";
        div.style.zIndex = 1;
        div.style.height = "50px"
        div.style.width = "15px"
        div.innerText = "."
        div.style.color = "darkblue"
        div.style.opacity = 0.8;
        div.style.left = "341px"
        div.style.borderRadius = "4px 4px 4px 4px";
        div.style.top = "" + json_map.maps.trajet[element][2].distance - 55 + P + "px";
        
        verifed = true;
        
        var div2 = document.createElement("a");
        document.getElementById('train element').appendChild(div2);
        div2.style.position = "absolute";
        div2.style.left = "345px"
        div2.style.color = "white"
        div2.style.zIndex = "1"
        div2.style.backgroundColor = "#FFFFFF40"
        div2.style.top = "" + json_map.maps.trajet[element][2].distance - 40 + P + "px";
        div2.innerText = json_map.maps.trajet[element][1];
        div2.style.scale = "0.5";
        div2.style.borderRadius = "4px 4px 4px 4px";
        
        var m = document.createElement("a");
        document.getElementById('train element').appendChild(m);
        m.style.position = "absolute";
        m.style.backgroundColor = "darkblue";
        m.style.zIndex = 1;
        m.style.color = "white"
        m.style.height = "50px"
        m.style.width = "15px"
        m.style.opacity = 0.7;
        m.innerText = "."
        m.style.color = "darkblue"
        m.style.borderRadius = "4px 4px 4px 4px";
        m.style.left = "288.4px"
        m.style.top = "" + json_map.maps.trajet[element][2].distance - 55 + P + "px";
        
      }
      
      if (div.innerText == "BG anim" || div.innerText == "AWS") {
        div.remove()
      }
      
      if (div.innerText == "AWS") {
        var m = document.createElement("a");
        document.getElementById('train element').appendChild(m);
        m.style.position = "absolute";
        m.style.backgroundColor = "yellow";
        m.style.zIndex = 0;
        m.style.color = "yellow"
        m.style.height = "15px"
        m.style.width = "15px"
        m.innerText = "";
        m.style.scale = 0.8;
        m.style.opacity = 0.5
        m.style.color = "blue"
        m.style.borderRadius = "50px";
        m.style.left = "305px"
        m.style.top = ""+ json_map.maps.trajet[element][2].distance + "px";
      }
      
      
      // console.log(json_map.maps.trajet[element][2].distance * 0.05,Y)
      element++;
    }
    Y += 1;
  }
}

function fresh() {
  document.getElementById("train element").remove();
  
  var div = document.createElement("div");
  div.id = "train element";
  document.body.appendChild(div);
  // yeah , it really bad xd
  
  refresh_time++;
  train_Selecte2()
}

function makeTrainIngame(p) {
  if (disableTrain !== "true") {
  mtp_counter++;
  console.log("(MTP) make , id:"+"T"+mtp_counter)
  
  var mtp = document.createElement('img');
  document.getElementById("train element").appendChild(mtp);
  mtp.src = "images/mini_train passing/1.png";
  mtp.style.position = "absolute";
  mtp.style.scale = "0.12";
  mtp.style.left = "262px"
  mtp.style.top = "-500px";
  
  mtp.id = "T"+mtp_counter;
  var x = "na";
  if (p == null) {
    x = json_map.maps.trajet[json_map.maps.trajet.length - 1][2].distance - 250
  } else {
    x = p;
  }
  var loop = setInterval(() => {
    mtp.style.top = x + "px";
    x = x - mtp_speed;
    if (x <= sessionStorage.getItem("meter") - 250) {
      clearInterval(loop)
      mtp.remove()
      console.log("(MTP) id:"+mtp.id+" delete")
    }
  },0)
  }
}

var mposition = 0;
setInterval(() => {
  if (i2 == 0) {
    
    mposition = sessionStorage.getItem("meter");
    mposition -= 12;
    document.getElementById("train element").style.top = "-"+mposition+"px";
  }
},0)


function looop() {
  var random = 0;
  if (mtp_counter >= 2) {
    random = Math.random() * 5000; // 5 sec
    random += 30000; // 25 sec
  } 
  
  if (mtp_counter >= 3) {
    mtp_speed = 0.05;
  }
  
  var loopl = setInterval(() => {
    makeTrainIngame()
    
    clearInterval(loopl)
    looop()
  },random)
}

function other() {
  
}


sessionStorage.setItem("mini Gui",false);

document.onclick = function () {
  if (i2 == 1) {
    i2 = 0;
    sessionStorage.setItem("mini Gui",false)
  } else {
    i2 = 1;
    sessionStorage.setItem("mini Gui",true)
  }
}