let json_train = "";
let json_train_link = "";
let selected = "null";
let train_json = null;
let refresh_time = 0;
let json_map_link = "assets/Maps/L1/";
let reset = false;

function getElement(name) {
  return document.getElementById(name)
}

function train_Selecte1(param) {
  train_json = "assets/Trains/"+document.getElementById("input1").value+"/main.json";
  json_train_link = "assets/Trains/"+document.getElementById("input1").value+"/";
  train_Selecte2();
}

function get_maps_json(link) {
  // get the json file
  var rawFile = new XMLHttpRequest();
  var reload = 0;
  rawFile.open("get",json_map_link+"main.json", true);
  rawFile.onreadystatechange = function() {
    reload++;
    if (rawFile.readyState === 4) {
      var allText = rawFile.responseText;
    }
    if (reload == 3) {
      
      if (allText == "Error 404, file not found.") {
        alert("error ! | sorry no maps asset found");
      } else {
        json_ligne = JSON.parse(allText);
        train_element()
      }
    }
  }
  rawFile.send();
}

function train_element() {
  makeLocalAnim(document.getElementById("input1").value,json_map_link + json_ligne["body"][document.getElementById("input1").value][0],json_ligne["body"][document.getElementById("input1").value][1], json_ligne["body"][document.getElementById("input1").value][2].xyz[0], json_ligne["body"][document.getElementById("input1").value][2].xyz[1],json_ligne["body"][document.getElementById("input1").value][2].xyz[2])
}

function makeLocalAnim(name, animScr, animLength, x, y, scale) {
  for (var i = 0; i < animLength + 1; i++) {
    var thing = document.createElement("img"); // or document.getElementById(custom document id here).createElement("img");
    //                                   ↑ it can be a ("a") for text
    document.getElementById("train element").appendChild(thing);
    
    // custom setting
    thing.style.position = "absolute"; // or if you want a precise position ⟨ .left = "0px"; ⟩
    thing.style.zindex = "-5";
    thing.style.scale = scale
    if (refresh_time <= 1) {
      thing.style.left = x + "px";
      thing.style.top = y + "px";
      document.getElementById("X").value = x
      document.getElementById("Y").value = y
      document.getElementById("Z").value = scale
    } else {
      thing.style.left = document.getElementById("X").value + "px";
      thing.style.top = document.getElementById("Y").value  + "px";
      thing.style.scale = document.getElementById("Z").value;
    }
    thing.style.backgroundColor = "black";
    
    // do not modify 
    thing.id = name + i;
    thing.style.visibility = "hidden";
    thing.src = animScr + i + ".png";
    
    
    console.log(name + i + " | " + animLength + " create")
  }
  document.getElementById("m").style.zIndex = "5"
  
  document.getElementById("X").style.zIndex = "6"
  document.getElementById("X").style.zIndex = "6"
  
  document.getElementById("home").style.zIndex = "5"
  document.getElementById("re").style.zIndex = "5"
  document.getElementById("Y").style.zIndex = "6"
  document.getElementById("Z").style.zIndex = "6"

  playLocalAnim(document.getElementById("input1").value,json_ligne["body"][document.getElementById("input1").value][1],100)
}

function scaleLocalAnim(name, animLength, value) {
  for (var i = 0; i < animLength + 1; i++) {
    document.getElementById(name + i).style.scale = value;
  }
  //alert(name +" , "+ animLength+" , "+value)
}

function playLocalAnim(name, animLength, speed) {
  lo()
  console.log(name +" | "+animLength+" | "+speed)
  function lo() {
    
  var localAnimValue = {
    i: 0,
    i2: 0,
    i3: 0,
    L2: animLength + 1,
    value: 0
  };
  
    
  var p = setInterval(() => {
    if (true) {
    if (localAnimValue.i2 == 0) {
      /*document.getElementById(name + localAnimValue.i).style.zindex = "5px";
      document.getElementById(name + localAnimValue.i).style.opacity = 0.5;*/
      document.getElementById(name + localAnimValue.i).style.visibility = "visible"
      
      
      localAnimValue.i2 = 1;
    } else {
      /*document.getElementById(name + localAnimValue.i).style.zindex = "0"
      document.getElementById(name + localAnimValue.i).style.opacity = 1;*/
      document.getElementById(name + localAnimValue.i).style.visibility = "hidden"
      
      localAnimValue.i2 = 0;
      localAnimValue.i++;
      localAnimValue.i3 = localAnimValue.i + 1;
    }
    
    
    if (localAnimValue.i >= localAnimValue.L2) {
      localAnimValue.i = 0;
      localAnimValue.i2 = 0;
      localAnimValue.i3 = 1;
      document.getElementById(name + localAnimValue.i).style.visibility = "visible";
      clearInterval(p)
      clearInterval(this)
      if (reset == true) {
        lo()
        reset = false;
      }
    } else {
      document.getElementById(name + localAnimValue.i).style.visibility = "visible";
      
    }
    //console.log(localAnimValue.i,document.getElementById(name + localAnimValue.i).style.zindex)
    } else {
      document.getElementById(name + localAnimValue.i).style.visibility = "visible"
    }

  },speed)
  }
}

function fresh() {
  get_maps_json()
  document.getElementById("train element").remove();
  
  var div = document.createElement("div");
  div.id = "train element";
  document.body.appendChild(div);
  // yeah , it really bad xd
  reset = true;
  refresh_time++;
  train_element()
}