console.clear()
var version = 5.0

// make let object

let chose_train = localStorage.getItem("train select");
let chose_maps = localStorage.getItem("map select");
let chose_ligne = localStorage.getItem("ligne select");

// load map path

let json_map = "assets/Maps/" + chose_maps + "/main.json";
let json_map_link = "assets/Maps/" + chose_maps + "/";
get_maps_json(json_map)

// load ligne path

let json_ligne = "assets/Lignes/" + chose_ligne + ".json";
get_ligne_json(json_ligne)

// load train path

let json_train = "assets/Trains/" + chose_train + "/main.json";
let json_train_link = "assets/Trains/" + chose_train + "/";
get_train_json(json_train)


// other let ( var ) thing

let train = {
  element: document.getElementById("train element"),
  
  position: {
    x: undefined,
    y: undefined
  },
  
  speedMonitor: {
    type: null,
    value: null
  },
  
  moveSens: 0,
  
  buttonClickAudio: null,
  
  moved: false,
  
  tension_up: false,
  tension_dows: false,
  
  show_speed: 120, // inversed , if speed = 0 then speed2 = 120
  speed: 0,
  speed2: 0, // speed but text
  
  traction_speed: null,
  
  passager: 0,
  max_passager: 130,
  
  in_station: false,
  
  light: {
    light_interior: false,
    light_exterior: true
  },
  
  door: {
    value: 1,
    door_alert: false,
    on: false,
    
    audio: {
      open: null,
      close: null,
      bell: null
    }
  },
  
  power: "off",
  motor: "off",
  pantograph: "downs",
  AWS: false
}

// game data

let game = {
  timer: {
    A: 1,
    disable: false
  },
  
  mode: {
    editor: false,  // false
    disable_AWS: false,  // false
    night: true, // 
    loadingScreen: false,  // true
    
    timer: localStorage.getItem('HTS setting timer mods')
  },
  
  camera: 1,
  
  version: null,
  
  log: (text) => {
    if (text !== undefined) {
      var l = document.createElement("log")
      l.innerText = text;
      document.getElementById("log").appendChild(l)
    }
    
    return document.getElementById("log");
  },
  
  
  loadingScreen: function() {
    loading_screen();
  },
  
  loadingScreenEnd: false,
  
  meter: 0,
  meter2: null,
  mini_map: true,
  
  popup1: {
    warning: false,
    speed_limit: 120
  },
  
  station: {
    last_station: null,
    next_station: null,
    next_station_distance: null,
  },
  
  event: {
    event: null,
    station: null,
  },
  
  sound: {
    ding: null,
    awsding: null,
    stationAmbiance: new Audio("sounds/station ambiance.mp3")
  }
}

let script = {
  getFileLoad: 0
}

let loop1;
let reset_loop1 = false;

var k = 0;

// get main.json in train path
console.log("%c load Json from path...","color: green; background-color: grey; padding: 2px",);

if (game.mode.loadingScreen == true) {
  game.loadingScreen();
}

function get_train_json(link) {
  // get the json file
  var rawFile = new XMLHttpRequest();
  var reload = 0;
  rawFile.open("get", link, true);
  rawFile.onreadystatechange = function() {
    reload++;
    if (rawFile.readyState === 4) {
      var allText = rawFile.responseText;
    }
    if (reload == 3) {
      
      if (allText == "Error 404, file not found.") {
        error("no train folder asset found")
        script.getFileLoad = -2;
      } else {
        
        json_train = JSON.parse(allText);
        
        train.traction_speed = json_train["train option"].speed * 100;
        //train.power = json_train["train option"]["power on?"]
        
        train.speedMonitor.type = json_train.body["speed counter"].type;
        
        script.getFileLoad += 1;
      }
    }
  }
  rawFile.send();
}

function get_maps_json(link) {
  // get the json file
  var rawFile = new XMLHttpRequest();
  var reload = 0;
  rawFile.open("get", link, true);
  rawFile.onreadystatechange = function() {
    reload++;
    if (rawFile.readyState === 4) {
      var allText = rawFile.responseText;
    }
    if (reload == 3) {
      
      if (allText == "Error 404, file not found." && script.getFileLoad >= -1) {
        error("no Maps folder asset found");
        script.getFileLoad = -2;
      } else {
        json_map = JSON.parse(allText);
        
        script.getFileLoad += 1;
      }
    }
  }
  rawFile.send();
}

function get_ligne_json(link) {
  // get the json file
  var rawFile = new XMLHttpRequest();
  var reload = 0;
  rawFile.open("get", link, true);
  rawFile.onreadystatechange = function() {
    reload++;
    if (rawFile.readyState === 4) {
      var allText = rawFile.responseText;
    }
    if (reload == 3) {
      
      if (allText == "Error 404, file not found." && script.getFileLoad >= -1) {
        error("no Ligne element asset found");
        script.getFileLoad = -2;
      } else {

        json_ligne = JSON.parse(allText);
        get_version_json()
        
        script.getFileLoad += 1;
      }
    }
  }
  rawFile.send();
}

function get_version_json() {}

// load thing like sound 

game.sound.stationAmbiance.play()
game.sound.stationAmbiance.volume = 0;

var antiLoop = [0,10];
var loop = setInterval(() => {
  antiLoop[0]++;
  
  /*if (antiLoop[0] >= antiLoop[1]) {
    error("fail to get all data file, please try again")
    console.log("naaa")
  }*/
  
  if (script.getFileLoad >= 3) {
    antiLoop[0] = -100;
    console.log("%c loading finished","color: green; background-color: grey; padding: 2px",);
    console.log("");
    console.log("%c loading Element 0/3 ...","color: green; background-color: grey; padding: 2px",);
    
    
    loop3();
    loop2();
    loop4();
    
    
    maps_element();
    train_element();
    clearInterval(loop)
    
    interact_load()
    
    if (game.mode.loadingScreen == false) {
      onloading_end()
    }
    
    document.getElementById("DNR").style.visibility = "visible";
    /*document.getElementById("timer").style.visibility = "visible";
    document.getElementById("n").style.visibility = "visible";*/
    document.getElementById("mini maps").style.visibility = "visible";
    //document.getElementById("MM button").style.visibility = "visible";

    game.mode.night = json_ligne.maps["mode night"];
    game.timer.A = json_ligne.maps.timer;
    
    game.sound.ding = new Audio("sounds/ding.mp3");
    game.sound.awsding = new Audio("sounds/AWS-ding.mp3");
    
    document.getElementById("version").innerText = "v"+version;
    game.version = version;
  }
}, 0)

var thing = setInterval(function() {
  if (train.speed >= 1) {
    train.moved = true;
    clearInterval(thing)
  }
})

// #loading screen 

function loading_screen() {
  var infLoad = false;
  var loading = document.createElement('img');
  
  document.body.appendChild(loading);
  loading.style.position = "absolute";
  loading.src = "images/loading1.gif";
  loading.style.left = "-210px";
  loading.style.top = "-150px";
  loading.style.zIndex = "5";
  loading.style.scale = 0.8;
  loading.style.border = "10pc solid black"
  loading.style.backgroundColor = "black";
  
  var B = Math.random() * 100;
  if (game.mode.editor == true) {
    var A = 9999;
  } else {
    var A = 0;
  }
  var C = 20.5;
  B = B + 50;
  
  var looop = setInterval(function() {
    A++;
    // console.log(A + "/"+ B + "/" + C)
    if (A >= B && script.getFileLoad >= 3 && infLoad == false) {
      if (C <= 0.1) {
        clearInterval(looop);
        loading.remove();
        //console.clear();
        onloading_end();
        game.loadingScreenEnd = true;
      }
      C -= 0.04;
      loading.style.opacity = C;
    }
  }, 1)
}

// all asset ( yep )

function train_element() {
  
  for (var i = 0; i < 10; i++) {
    document.getElementById("train element").remove()
    document.getElementById("2D train element").remove()
    
    const a = document.createElement("div")
    a.id = "train element";
    a.style.position = "absolute";
    a.style.left = "0px";
    a.style.scale = json_train["train option"]["cabine zoom"];
    document.body.appendChild(a)

    const b = document.createElement("div")
    b.id = "2D train element";
    b.style.position = "absolute";
    b.style.top = "0px"
    b.style.zIndex = 3;
    b.style.visibility = "hidden";
    document.body.appendChild(b)

    var body1 = document.createElement("img")
    document.getElementById("train element").appendChild(body1);
    
    
    nall(json_train["body"]["body"][0] + " add")
    body1.style.position = "absolute";
    body1.src = json_train_link + json_train["body"]["body"][0] + ".png";
    body1.style.left = json_train["body"]["body"][1].x + "px";
    body1.onerror = function() {
      errorPng()
    }
    
    body1.style.top = json_train["body"]["body"][1].y + "px";
    body1.style.zIndex = "0";
    body1.style.scale = json_train["body"]["body"][1].scale;
    body1.id = "train body";
    
    if (json_train.body.button["pre-closing doors"] !== false) {
      let doors4 = document.createElement("img")
      document.getElementById("train element").appendChild(doors4);
      
      var id = json_train.body.button["pre-closing doors"]
      nall(id[0] + " add")
      doors4.style.position = "absolute";
      doors4.src = json_train_link + id[0] + ".png";
      doors4.style.left = id[1].x + "px";
      doors4.style.top = id[1].y + "px";
      doors4.style.zIndex = "0";
      doors4.style.scale = id[1].scale;
      doors4.onerror = function () {
        errorPng()
      }
      doors4.onclick = function() {
        button_click()
      }
    }
    
    if (json_train.body.button["tension up"] !== false) {
      let tensionup = document.createElement("img")
      document.getElementById("train element").appendChild(tensionup);
      
      
      var id = json_train.body.button["tension up"]
      nall(id[0] + " add")
      tensionup.style.position = "absolute";
      tensionup.src = json_train_link + id[0] + ".png";
      tensionup.style.left = id[1].x + "px";
      tensionup.style.top = id[1].y + "px";
      tensionup.style.zIndex = "0";
      tensionup.style.scale = id[1].scale;
      tensionup.id = "tensionup";
      tensionup.onclick = function() {
        button_click()
        if (train.tension_up == false) {
          train.tension_up = true;
          tensionup.src = json_train_link + json_train.body.button["tension up"][1]["img2"] + ".png";
        } else {
          train.tension_up = false;
          tensionup.src = json_train_link + json_train.body.button["tension up"][0] + ".png";
        }
      }
    }
    
    if (json_train.body.button["tension dows"] !== false) {
      let tensiondows = document.createElement("img")
      document.getElementById("train element").appendChild(tensiondows);
      
      
      var id = json_train.body.button["tension dows"]
      nall(id[0] + " add")
      tensiondows.style.position = "absolute";
      tensiondows.src = json_train_link + id[0] + ".png";
      tensiondows.style.left = id[1].x + "px";
      tensiondows.style.top = id[1].y + "px";
      tensiondows.style.zIndex = "0";
      tensiondows.style.scale = id[1].scale;
      tensiondows.id = "tensiondows";
      tensiondows.onclick = function() {
        button_click()
        if (train.speed >= 1) {
          
        }
        if (train.tension_dows == false) {
          train.tension_dows = true;
          tensiondows.src = json_train_link + json_train.body.button["tension dows"][1]["img2"] + ".png";
        } else {
          train.tension_dows = false;
          tensiondows.src = json_train_link + json_train.body.button["tension dows"][0] + ".png";
        }
      }
    }
    

    if (json_train.body.button["horn1"] !== false) {
      let horn1 = document.createElement("img")
      document.getElementById("train element").appendChild(horn1);
      
      var id = json_train.body.button["horn1"]
      nall(id[0] + " add")
      horn1.style.position = "absolute";
      horn1.src = json_train_link + id[0] + ".png";
      horn1.style.left = id[1].x + "px";
      horn1.style.top = id[1].y + "px";
      horn1.style.zIndex = "0";
      horn1.style.scale = id[1].scale;
      horn1.onclick = function() {
        button_click()
        
        if (json_train.sound.horn1[0] !== false) {
          var hornn = new Audio(json_train.sound.horn1[0]);
          hornn.volume = json_train.sound.horn1[1].volume;
          hornn.play();
        }
      }
    }
    
    if (json_train.body.button["horn2"] !== false) {
      let horn2 = document.createElement("img")
      document.getElementById("train element").appendChild(horn2);
      
      var id = json_train.body.button["horn2"]
      nall(id[0] + " add")
      horn2.style.position = "absolute";
      horn2.src = json_train_link + id[0] + ".png";
      horn2.style.left = id[1].x + "px";
      horn2.style.top = id[1].y + "px";
      horn2.style.zIndex = "0";
      horn2.style.scale = id[1].scale;
      horn2.onclick = function() {
        button_click()
      }
    }
    
    if (json_train.body.button["doors open/close"][0] !== false) {
      let door1 = document.createElement("img")
      document.getElementById("train element").appendChild(door1);
      
      var id2 = json_train.body.button["doors open/close"][0]
      nall(id2[0] + " add")
      door1.style.position = "absolute";
      door1.src = json_train_link + id2[0] + ".png";
      door1.style.left = id2[1].x + "px";
      door1.style.top = id2[1].y + "px";
      door1.style.zIndex = "0";
      door1.style.scale = id2[1].scale;
      door1.id = "button_opendoors"
      door1.onclick = function() {
        button_click()
        
        if (train.speed <= 1) {
          doors("open");
        }
      }
    }
    
    if (json_train.body.button["doors open/close"][1] !== false) {
      let door2 = document.createElement("img")
      document.getElementById("train element").appendChild(door2);
      
      var id2 = json_train.body.button["doors open/close"][1]
      nall(id2[0] + " add")
      door2["id"] = "button_closedoors";
      door2.style.position = "absolute";
      door2.src = json_train_link + id2[0] + ".png";
      door2.style.left = id2[1].x + "px";
      door2.style.top = id2[1].y + "px";
      door2.style.zIndex = "0";
      door2.style.scale = id2[1].scale;
      
      door2.onclick = function() {
        button_click()
        
        doors("close");
      }
    }
    
    if (json_train.body.button["light1"] !== false) {
      let light1 = document.createElement("img")
      document.getElementById("train element").appendChild(light1);
      
      var id = json_train.body.button["light1"]
      nall(id[0] + " add")
      light1.style.position = "absolute";
      light1.src = json_train_link + id[0] + ".png";
      light1.style.left = id[1].x + "px";
      light1.style.top = id[1].y + "px";
      light1.style.zIndex = "0";
      light1.style.scale = id[1].scale;
      light1.onclick = function() {
        button_click()
        if (train.power == "on") {
        if (train.light.light_interior == true) {
          train.light.light_interior = false;
        } else {
          train.light.light_interior = true;
        }
        
        
          if (train.light.light_interior == true && document.getElementById("train body").src !== json_train_link + json_train["body"]["body"][1]["body in_ligth_up"] + ".png") {
            document.getElementById("train body").src = json_train_link + json_train["body"]["body"][1]["body in_ligth_up"] + ".png";
          } else if (train.light.light_interior == false && document.getElementById("train body").src !== json_train_link + json_train["body"]["body"][0] + ".png") {
            document.getElementById("train body").src = json_train_link + json_train["body"]["body"][0] + ".png";
          }
        }
        
      }
      
      if (json_train.body !== false) {
        let light1 = document.createElement("img")
        document.getElementById("train element").appendChild(light1);
        
        var id = json_train.body.button["light1"]
        nall(id[0] + " add")
        light1.style.position = "absolute";
        light1.src = json_train_link + id[0] + ".png";
        light1.style.left = id[1].x + "px";
        light1.style.top = id[1].y + "px";
        light1.style.zIndex = "0";
        light1.style.scale = id[1].scale;
        light1.onclick = function() {
          button_click()
          
          if (train.power == "on") {
          if (train.light.light_interior == true) {
            train.light.light_interior = false;
          } else {
            train.light.light_interior = true;
          }
          
          if (train.light.light_interior == true && document.getElementById("train body").src !== json_train_link + json_train["body"]["body"][1]["body in_ligth_up"] + ".png") {
            document.getElementById("train body").src = json_train_link + json_train["body"]["body"][1]["body in_ligth_up"] + ".png";
          } else if (train.light.light_interior == false && document.getElementById("train body").src !== json_train_link + json_train["body"]["body"][0] + ".png") {
            document.getElementById("train body").src = json_train_link + json_train["body"]["body"][0] + ".png";
          }
          }
        }
      }
      
      if (json_train.body.button["light2"] !== false) {
        let light2 = document.createElement("img")
        document.getElementById("train element").appendChild(light2);
        
        var id = json_train.body.button["light2"]
        nall(id[0] + " add")
        light2.style.position = "absolute";
        light2.src = json_train_link + id[0] + ".png";
        light2.style.left = id[1].x + "px";
        light2.style.top = id[1].y + "px";
        light2.style.zIndex = "0";
        light2.style.scale = id[1].scale;
        light2.onclick = function() {
          button_click()
          
          if (train.power == "on") {
          if (train.light.light_exterior == true) {
            train.light.light_exterior = false;
          } else {
            train.light.light_exterior = true;
          }
          }
        }
      }
      
      if (json_train.body.button["light3"] !== false) {
        let light3 = document.createElement("img")
        document.getElementById("train element").appendChild(light3);
        
        var id = json_train.body.button["light3"]
        nall(id[0] + " add")
        light3.style.position = "absolute";
        light3.src = json_train_link + id[0] + ".png";
        light3.style.left = id[1].x + "px";
        light3.style.top = id[1].y + "px";
        light3.style.scale = id[1].scale;
        light3.style.zIndex = "0";
        light3.onclick = function() {
          button_click()
        }
      }
      
      if (json_train.body.button["interior light"] !== false) {
        let interior_light = document.createElement("img")
        document.getElementById("train element").appendChild(interior_light);
        
        var id = json_train.body.button["interior light"]
        nall(id[0] + " add")
        interior_light.style.position = "absolute";
        interior_light.src = json_train_link + id[0] + ".png";
        interior_light.style.left = id[1].x + "px";
        interior_light.style.top = id[1].y + "px";
        interior_light.style.scale = id[1].scale;
        interior_light.style.zIndex = "0";
        interior_light.onclick = function() {
          button_click()
        }
      }
      
      if (json_train.body["speed counter"] !== false) {
        if (train.speedMonitor.type == 1) {
        let guispeed = document.createElement("a")
        document.getElementById("train element").appendChild(guispeed);
        
        console.log(`hk`)
        
        var id = json_train.body["speed counter"];
        nall("speed counter" + " add")
        guispeed.style.position = "absolute";
        guispeed.style.left = id.x + "px";
        guispeed.style.top = id.y + "px";
        guispeed.style.scale = id.scale;
        guispeed.innerText = "50 km/h";
        guispeed.style.color = "white"
        guispeed.style.backgroundColor = "black"
        guispeed.style.zIndex = "2";
        guispeed.id = "guispeed";
        } else {
        document.getElementById("New speed counter").style.visibility = "visible"
        
        var id = json_train.body["speed counter"];
        document.getElementById("New speed counter").style.left = id.x + "px";
        document.getElementById("New speed counter").style.top = id.y + "px";
        document.getElementById("New speed counter").style.scale = id.scale;
      }
    }
      
      if (json_train.body.button["AWS"] !== false) {
        let AWS = document.createElement("img")
        document.getElementById("train element").appendChild(AWS);
        
        var id = json_train.body.button["AWS"]
        nall(id[0] + " add")
        AWS.style.position = "absolute";
        AWS.src = json_train_link + id[0] + ".png";
        AWS.style.left = id[1].x + "px";
        AWS.style.top = id[1].y + "px";
        AWS.style.scale = id[1].scale;
        AWS.style.zIndex = "0";
        AWS.id = "aws";
        AWS.onclick = function() {
          button_click()
          if (train.speed <= game.popup1.speed_limit + 4) {
            train.AWS = false;
            document.getElementById("aws").style.filter = "brightness(" + 100 + "%)";
          }
        }
      }
      
      let D_BGT = document.createElement("img")
      document.getElementById("2D train element").appendChild(D_BGT);

      D_BGT.style.position = "absolute";
      D_BGT.src = "images/2D train view-template BG.png";
      D_BGT.style.left = 200 + "px";
      D_BGT.style.top = 100 + "px";
      D_BGT.id = "D_BGT";
      D_BGT.style.scale = 3;
      D_BGT.onerror = function() {
        errorPng()
      }
      
    if (json_train["2D train view"]["body"] !== false) {
      let D_body = document.createElement("img")
      document.getElementById("2D train element").appendChild(D_body);
      
      var id = json_train["2D train view"]["body"]
      nall(id[0] + " add")
      D_body.id = "train2D 1"
      D_body.style.position = "absolute";
      D_body.src = json_train_link + id[0] + ".png";
      D_body.style.left = id[1].x + "px";
      D_body.style.top = id[1].y + "px";
      D_body.style.zIndex = "2";
      D_body.style.scale = id[1].scale;
      D_body.onclick = function() {}
    }
    
    if (json_train["2D train view"]["body"] !== false) {
      let D_body2 = document.createElement("img")
      document.getElementById("2D train element").appendChild(D_body2);
      
      var id = json_train["2D train view"]["body"]
      nall(id[0] + " add")
      D_body2.id = "train2D 2"
      D_body2.style.position = "absolute";
      D_body2.src = json_train_link + id[1]["body in_ligth_up"] + ".png";
      D_body2.style.left = id[1].x + "px";
      D_body2.style.top = id[1].y + "px";
      D_body2.style.zIndex = "2";
      D_body2.style.scale = id[1].scale;
      D_body2.onclick = function() {}
    }


    if (i >= 9) {
      console.log("%c loading Element 1/3 ...","color: green; background-color: grey; padding: 2px",);
    }
      
      for (var m = 0; m < json_train.body.button["other..."].length; m++) {
        if (json_train.body.button["other..."] !== false) {
          let otherB = document.createElement("img")
          document.getElementById("train element").appendChild(otherB);
          
          var id = json_train.body.button["other..."][m]
          console.log(id[0] + " add")
          otherB.style.position = "absolute";
          otherB.src = json_train_link + id[0] + ".png";
          otherB.style.left = id[1].x + "px";
          otherB.style.top = id[1].y + "px";
          otherB.style.scale = id[1].scale;
          otherB.style.zIndex = "0";
          otherB.id = m;
          otherB.onclick = function() {
            
            if (json_train.body.button["other..."][otherB.id][1].type[1][1] == true) {
              button_click()
            }
            
            if (json_train.body.button["other..."][otherB.id][1].type[0] == "sound") {
              var audio = new Audio(json_train_link + json_train.body.button["other..."][otherB.id][1].type[1][0])
              audio.play()
            }
            
            if (json_train.body.button["other..."][otherB.id][1].type[0] == "function") {
              if (json_train.body.button["other..."][otherB.id][1].type[1] == "play thing") {
                /* a script here */
              }
            }
          }
        }
      if (m >= json_train.body.button["other..."].length) {
        console.log("%c loading Element 1/3 ...","color: green; background-color: grey; padding: 2px",);
      }
      }
    }
  }
}

function maps_element() {
  makeLocalAnim(json_ligne.maps["maps asset"][0], json_map_link + json_map["body"][json_ligne.maps["maps asset"][0]][0], json_map["body"][json_ligne.maps["maps asset"][0]][1], json_map["body"][json_ligne.maps["maps asset"][0]][2].xyz[0], json_map["body"][json_ligne.maps["maps asset"][0]][2].xyz[1])
  for (var i = 0; i < json_ligne.maps["maps asset"][1].length; i++) {
    makeLocalAnim(json_ligne.maps["maps asset"][1][i], json_map_link + json_map["body"][json_ligne.maps["maps asset"][1][i]][0], json_map["body"][json_ligne.maps["maps asset"][1][i]][1], json_map["body"][json_ligne.maps["maps asset"][1][i]][2].xyz[0], json_map["body"][json_ligne.maps["maps asset"][1][i]][2].xyz[1])
  }
  console.log("%c loading Element 3/3 ...","color: green; background-color: grey; padding: 2px",);
  console.log("%c load Element finished","color: green; background-color: grey; padding: 2px",);
}

// other things #sound #on...

function onloading_end() {
  
  if (game.mode.editor == true) {
    localStorage.getItem("train select");
    localStorage.getItem("map select");
    localStorage.getItem("ligne select");
  }
  
  //animation_loop()
  train_S();
  animStationLoop();
  loadMapsLocalAnim(100);
  LoadAudio()
  
  // play audio
  // not so good sytem / new Audio("assets/Lignes/"+json_ligne.maps["start announce"]).play()
}



function interact_load() {
  console.log("%c loading sound ...","color: green; background-color: grey; padding: 2px",);
  
  for (var i = 0; i < 20; i++) {
    // load sound
    
    if (json_train["sound"]["train sound type"] == "MP05") {
      var pre_ambiance1 = new Audio(json_train_link + json_train.sound.motor["starting ambiance1"][0] + ".ogg");
      pre_ambiance1.loop = true;
      pre_ambiance1.volume = json_train.sound.motor["starting ambiance1"][1].volume;
      
      var MP05_start1 = new Audio(json_train_link + json_train.sound.motor["MP05 start1"][0] + ".ogg");
      MP05_start1.loop = true;
      MP05_start1.volume = json_train.sound.motor["MP05 start1"][1].volume;
      
      var MP05_start2 = new Audio(json_train_link + json_train.sound.motor["MP05 start2"][0] + ".ogg");
      MP05_start2.loop = true;
      MP05_start2.volume = json_train.sound.motor["MP05 start2"][1].volume;
    }
    
    if (json_train["sound"]["train sound type"] == "Z5300") {
      var onTensionUp = new Audio(json_train_link + json_train.sound.motor["tension up/ambiance"][0] + ".ogg");
      onTensionUp.loop = true;
      onTensionUp.volume = json_train.sound.motor["tension up/ambiance"][1].volume;
      
      var loopAmbiance = new Audio(json_train_link + json_train.sound.motor["loop ambiance"][0] + ".ogg");
      loopAmbiance.loop = true;
      loopAmbiance.volume = json_train.sound.motor["loop ambiance"][1].volume;
      
      var z53motor = new Audio(json_train_link + json_train.sound.motor["motor"][0] + ".ogg");
      z53motor.loop = true;
      z53motor.volume = json_train.sound.motor["motor"][1].volume;
      z53motor.onerror = function() {
        errorAudio("z5300 motor")
      }
    }
    
    var ambiance1 = new Audio(json_train_link + json_train.sound.motor["ambiance1"][0] + ".ogg");
    ambiance1.loop = true;
    ambiance1.volume = json_train.sound.motor["ambiance1"][1].volume;
    ambiance1.onerror = function() {
      errorAudio("ambiance1")
    }
    
    var ambiance2 = new Audio(json_train_link + json_train.sound.motor["ambiance2"][0] + ".ogg");
    ambiance2.loop = true;
    ambiance2.volume = json_train.sound.motor["ambiance2"][1].volume;
    ambiance2.onerror = function() {
      //errorAudio("ambiance2")
    }
    
    var neutre1 = new Audio(json_train_link + json_train.sound.motor["neutre1"][0] + ".ogg");
    neutre1.loop = true;
    neutre1.volume = json_train.sound.motor["neutre1"][1].volume;
    neutre1.onerror = function() {
      errorAudio("neutre1")
    }
    
    var onBrack = new Audio(json_train_link + json_train.sound.motor["brack"][0] + ".ogg");
    onBrack.loop = true;
    onBrack.volume = json_train.sound.motor["brack"][1].volume;
    onBrack.onerror = function() {
      
    }
    
    var warning_doors = new Audio(json_train_link + json_train.sound["pre-closing doors"][0] + ".ogg");
    warning_doors.loop = true;
    warning_doors.volume = 0;
    
    var aws_sound = new Audio(json_train_link + json_train.sound["AWS"][0] + ".ogg");
    aws_sound.loop = true;
    aws_sound.volume = 0;
    
  }
  
  // play all sound
  
  ambiance1.play();
  ambiance2.play();
  neutre1.play();
  warning_doors.play();
  aws_sound.play();
  
  if (json_train["sound"]["train sound type"] == "MP05") {
    pre_ambiance1.play();
    MP05_start1.play();
    MP05_start2.play();
  }
  
  if (json_train["sound"]["train sound type"] == "Z5300") {
    onTensionUp.play()
    loopAmbiance.play()
    z53motor.play()
  }


  
  // other...
  
  var T = null;
  var pitcht = null;
  console.log("%c load sound finished ...","color: green; background-color: grey; padding: 2px",);

  setInterval(function() {
    if /* default sound mode */ (json_train["sound"]["train sound type"] == "default") {
      T = train.speed // * 0.5;
      pitcht = T * 1;
      
      ambiance1.playbackRate = pitcht / json_train["sound"]["normal-ambiance1 speed pitch division"];
      ambiance1.preservesPitch = false;
      
      if (train.speed >= 1.5 ) {
        ambiance1.volume = json_train.sound.motor["ambiance1"][1].volume;
        neutre1.volume = 0;
      } else {
        if (train.moveSens !== 0 && train.motor !== "off") {
          neutre1.volume = json_train.sound.motor["neutre1"][1].volume;
        } else {
          neutre1.volume = 0
        }
        
        ambiance1.volume = 0;
      }
      // ambiance1.mozPreservesPitch = false 
      
      if (train.speed >= 0 && train.speed <= 1.1) {
        // ambiance1.currentTime = 1;
      }
    
      // aws 
    
      if (train.AWS == true) {
        aws_sound.volume = json_train.sound["AWS"][1].volume;
      } else if (train.AWS == false) {
        aws_sound.volume = 0;
      }
    
      if (train.door.value == 3) {
        warning_doors.volume = json_train.sound["pre-closing doors"][1].volume
      } else {
        warning_doors.volume = 0.000001;
      }
    }
    
    // ––––––––––––––––––––––––––
    
    if /* MP05 sound mode */ (json_train["sound"]["train sound type"] == "MP05") {
      T = train.speed // * 0.5;
      pitcht = T * 1;
      ambiance1.playbackRate = pitcht / json_train["sound"]["normal-ambiance1 speed pitch division"];
    
      if (train.speed >= 1.5 ) {
        if (train.speed >= 1 && train.speed <= json_train.sound.motor["starting ambiance1"][1]["max play"]) {
            ambiance1.volume = 0;
            pre_ambiance1.volume = json_train.sound.motor["starting ambiance1"][1].volume;
        } else if ( train.speed >= json_train.sound.motor["starting ambiance1"][1]["max play"]) {
            pre_ambiance1.volume = 0.00001;
            ambiance1.volume = json_train.sound.motor["ambiance1"][1].volume;
            neutre1.volume = 0;
        }
      } else {
        if (train.moveSens !== 0 && train.power !== "off") {
          neutre1.volume = json_train.sound.motor["neutre1"][1].volume;
        } else {
          neutre1.volume = 0;
        }        
        ambiance1.volume = 0;
        pre_ambiance1.volume = 0.00001;
      }
      // ambiance1.mozPreservesPitch = false 
      ambiance1.preservesPitch = false;
      if (train.speed >= 0 && train.speed <= 1.1) {
        // ambiance1.currentTime = 1;
      }
    
      // aws 
      
      if (train.speed >= 1 && train.speed <= json_train.sound.motor["starting ambiance1"][1]["max play"] / 2) {
        MP05_start1.volume = json_train.sound.motor["MP05 start1"][1].volume;
      } else {
        MP05_start1.volume = 0.0001;
      }

      if (train.speed >= json_train.sound.motor["starting ambiance1"][1]["max play"] / 2 && train.speed <= json_train.sound.motor["starting ambiance1"][1]["max play"]) {
        MP05_start2.volume = json_train.sound.motor["MP05 start2"][1].volume;
      } else {
        MP05_start2.volume = 0.0001;
      }


      if (train.AWS == true) {
        aws_sound.volume = json_train.sound["AWS"][1].volume;
      } else if (train.AWS == false) {
        aws_sound.volume = 0;
      }
    
      if (train.door.value == 3) {
        warning_doors.volume = json_train.sound["pre-closing doors"][1].volume
      } else {
        warning_doors.volume = 0.000001;
      }
    }

    // ––––––––––––––––––––––––––
    
    if /* Z5300 sound mode */ (json_train["sound"]["train sound type"] == "Z5300") {
      T = train.speed // * 0.5;
      pitcht = T * 1;
      
      ambiance1.playbackRate = pitcht / json_train["sound"]["normal-ambiance1 speed pitch division"];
      ambiance1.preservesPitch = false;
      onTensionUp.playbackRate = pitcht / json_train["sound"]["normal-ambiance1 speed pitch division"];
      onTensionUp.preservesPitch = false;

      if (train.speed >= 1.5 ) {
        ambiance1.volume = json_train.sound.motor["ambiance1"][1].volume;
        neutre1.volume = 0;
      } else {
        if (train.moveSens !== 0 && train.motor !== "off") {
          neutre1.volume = json_train.sound.motor["neutre1"][1].volume;
        } else {
          neutre1.volume = 0
        }
        
        ambiance1.volume = 0;
      }
      // ambiance1.mozPreservesPitch = false 
      
      if (train.speed >= 0 && train.speed <= 1.1) {
        // ambiance1.currentTime = 1;
      }
      
      if (train.speed >= 60) {
        z53motor.volume = json_train.sound.motor["motor"][1].volume;
      } else {
        z53motor.volume = 0;
      }
    
      // aws 
    
      if (train.AWS == true) {
        aws_sound.volume = json_train.sound["AWS"][1].volume;
      } else if (train.AWS == false) {
        aws_sound.volume = 0;
      }
    
      if (train.door.value == 3) {
        warning_doors.volume = json_train.sound["pre-closing doors"][1].volume
      } else {
        warning_doors.volume = 0.000001;
      }
      
      if (train.tension_up == true) {
        onTensionUp.volume = json_train.sound.motor["tension up/ambiance"][1].volume;
      } else {
        onTensionUp.volume = 0;
      }
      
    }

  }, 1)
}

// #doors and other

function nall(param) {
  // Tab to edit
}

function LoadAudio() {
  train.door.audio.open = new Audio(json_train_link + json_train.sound["doors open/close"][0] + ".ogg");
  train.door.audio.close = new Audio(json_train_link + json_train.sound["doors open/close"][1] + ".ogg");
  train.door.audio.bell = new Audio(json_train_link + json_train.sound["doors bell"] + ".ogg");
  
  train.buttonClickAudio = new Audio(json_train_link + json_train.sound.click[0] + ".ogg");
  train.buttonClickAudio.volume = json_train.sound.click[1].volume;
}

function doors(f) {
  if (train.power == "on") {
  var v = true;
  
  if /* Bell */ (f == "close" && train.door.value == 1 && v == false) {
    train.door.audio.bell.play()
  }
  
  if /* close doors */ (f == "close" && train.door.value == 3 && v == true) {
    train.door.audio.close.play()
    
    train.door.door_alert = false;
    train.door.on = false;
    
    train.door.value = 1;
    
    document.getElementById('button_closedoors').style.filter = "brightness(" + 100 + "%)";
    v = false;
  }
  
  if /* warning doors closing*/ (f == "close" && train.door.value == 2 && v == true) {
    train.door.value = 3;
    
    train.door.door_alert = true;
    
    document.getElementById('button_opendoors').style.filter = "brightness(" + 100 + "%)";
    document.getElementById('button_closedoors').style.filter = "brightness(" + 200 + "%)";
    v = false;
  }
  
  if /* open doors */ (f == "open" && train.door.value == 1 && v == true) {
    train.door.audio.open.play()
    
    train.tension_dows = false;
    train.tension_up = false;
    train.door.door_alert = false;
    
    train.door.value = 2;
    train.door.on = true;
    
    document.getElementById('button_opendoors').style.filter = "brightness(" + 200 + "%)";
    v = false;
  }
  }
}

function button_click() {
  train.buttonClickAudio.play();
}

// #maps gui
setInterval(function() {
  if (game.mini_maps == "false") {
    //document.getElementById("MM button").style.visibility = "visible";
    document.getElementById("mini maps").style.opacity = "0.95"
    document.getElementById("mini maps").style.left = "-260px"
    document.getElementById("mini maps2").style.visibility = 'visible';
    /*document.getElementById("n").style.visibility = 'visible';
    document.getElementById("timer").style.visibility = "visible"*/
    // show
  } else {
    // hide
    //document.getElementById("MM button").style.visibility = "hidden";
    /*document.getElementById("n").style.visibility = 'hidden';
    document.getElementById("timer").style.visibility = "hidden"*/
    document.getElementById("mini maps2").style.visibility = 'hidden';
    document.getElementById("mini maps").style.opacity = "0.2"
    document.getElementById("mini maps").style.left = "-365px"
  }
  
  if (train.light.light_interior == true) {
    document.getElementById('train element').style.filter = "brightness(" + 100 + "%)";
  } else {
    if (game.mode.night == true) {
      document.getElementById('train element').style.filter = "brightness(" + 40 + "%)"
    } else {
      document.getElementById('train element').style.filter = "brightness(" + 60 + "%)"
    }
  }
}, 0)


var g = 0;

function guide() {
  if (g == 0) {
    g = 1;
    
    document.getElementById('black BG').style.visibility = "visible";
    
    var guide = document.createElement('img')
    document.getElementById('GUI element').appendChild(guide)
    guide.id = "guide";
    guide.style.position = "absolute";
    guide.style.zIndex = "3";
    guide.style.border = "10px solid " + json_train["train option"].manuel[0][1].color;
    guide.style.scale = json_train["train option"].manuel[0][1].scale;
    guide.style.left = json_train["train option"].manuel[0][1].x + "px"
    guide.style.top = json_train["train option"].manuel[0][1].y + "px"
    guide.src = json_train_link + json_train["train option"].manuel[0][0] + ".png";
    
  } else {
    g = 0;
    document.getElementById('black BG').style.visibility = "hidden"
    document.getElementById('guide').remove();
  }
}

var menu_bars_value = 0;

function menu_bars() {
  if (menu_bars_value == 0) {
    document.getElementById("MB main").style.visibility = 'hidden';
    document.getElementById("MB arrows").style.left = "-100px";
    menu_bars_value = 1;
  } else {
    document.getElementById("MB main").style.visibility = 'visible';
    document.getElementById("MB arrows").style.left = "-35px";
    menu_bars_value = 0;
  }
}


// make element

function animStationLoop() {
  var i = 1;
  var i2 = 0;
  var i3 = 1;
  
  setInterval(() => {
    // put station BG
    
    if (train.in_station == true && i == 1) {
      scaleLocalAnim(json_ligne.maps["maps asset"][0], json_map.body[json_ligne.maps["maps asset"][0]][1], 0.00001);

      for (var p = 0; p < json_ligne.maps["maps asset"][1].length; p++) {
        scaleLocalAnim(json_ligne.maps["maps asset"][1][p], json_map.body[json_ligne.maps["maps asset"][1][p]][1], 0.00001);
      }
      
      i = 0;
      
      scaleLocalAnim(game.event.station[2]["BG anim"], json_map.body[game.event.station[2]["BG anim"]][1], json_map.body[game.event.station[2]["BG anim"]][2].xyz[2]);
      i2 = game.event.station[2]["BG anim"];
      
    } else if (train.in_station == false && i == 0) {
      scaleLocalAnim(json_ligne.maps["maps asset"][0], json_map.body[json_ligne.maps["maps asset"][0]][1], json_map.body[json_ligne.maps["maps asset"][0]][2].xyz[2]);
      i = 1;
      
      scaleLocalAnim(i2, json_map.body[i2][1], 0.00001);
      i2 = null;
    }
    
    // change BG anim ( small script )
    
    if (game.event.event[0] == "BG anim" && i3 == 1 && game.meter >= game.event.event[2].distance - 5) {
      i3 = 0;
      for (var n = 1; n < json_ligne.maps["maps asset"][1].length; n++) {
        scaleLocalAnim(json_ligne.maps["maps asset"][1][n], json_map.body[json_ligne.maps["maps asset"][1][n]][1], 0.00001);
      }
      scaleLocalAnim(game.event.event[1], json_map.body[game.event.event[1]][1], json_map.body[game.event.event[1]][2].xyz[2]);
    }
    if (game.event.event[0] !== "BG anim" && i3 == 0) { i3 = 1; }
    
    // end
  }, 0)
}

function makeLocalAnim(name, animScr, animLength, x, y) {
  for (var i = 0; i < animLength + 1; i++) {
    var thing = document.createElement("img"); // or document.getElementById(custom document id here).createElement("img");
    //                                   ↑ it can be a ("a") for text
    document.getElementById("maps element").appendChild(thing);
    
    // custom setting
    thing.style.position = "absolute"; // or if you want a precise position ⟨ .left = "0px"; ⟩
    thing.style.zindex = "0";
    thing.style.left = x + "px";
    thing.style.top = y + "px";
    thing.style.backgroundColor = "black";
    thing.onerror = function () {
      errorPng()
    }
    
    // do not modify 
    thing.id = name + i;
    thing.style.visibility = "hidden";
    thing.src = animScr + i + ".png";
    
    console.log(name + i + " | " + animLength + " create")
  }
}

function loadMapsLocalAnim(speed) {
  playLocalAnim(json_ligne.maps["maps asset"][0], json_map.body[json_ligne.maps["maps asset"][0]][1], json_map.body[json_ligne.maps["maps asset"][0]][2].speed);
  
  for (var i = 0; i < json_map.body[json_ligne.maps["maps asset"][0]][1] + 1; i++) {
    document.getElementById(json_ligne.maps["maps asset"][0] + i).style.scale = json_map.body[json_ligne.maps["maps asset"][0]][2].xyz[2];
  }
  
  for (var i = 0; i < json_ligne.maps["maps asset"][1].length; i++) {
    playLocalAnim(json_ligne.maps["maps asset"][1][i], json_map.body[json_ligne.maps["maps asset"][1][i]][1], json_map.body[json_ligne.maps["maps asset"][1][i]][2].speed)
  }
  
  for (var i = 0; i < json_ligne.maps["maps asset"][1].length; i++) {
    scaleLocalAnim(json_ligne.maps["maps asset"][1][i], json_map.body[json_ligne.maps["maps asset"][1][i]][1], 0.0001);
  }
}

function scaleLocalAnim(name, animLength, value) {
  for (var i = 0; i < animLength + 1; i++) {
    document.getElementById(name + i).style.scale = value;
  }
  //alert(name +" , "+ animLength+" , "+value)
}

function playLocalAnim(name, animLength, speed) {
  lo()
  nall(name + " | " + animLength + " | " + speed)
  
  function lo() {
    
    var localAnimValue = {
      i: 0,
      i2: 0,
      i3: 0,
      L2: animLength + 1,
      value: 0
    };
    
    
    var p = setInterval(() => {
      if (train.speed >= 1) {
        if (localAnimValue.i2 == 0) {
          /*document.getElementById(name + localAnimValue.i).style.zindex = "5px";
          document.getElementById(name + localAnimValue.i).style.opacity = 0.5;*/
          document.getElementById(name + localAnimValue.i).style.visibility = "visible"
          
          
          localAnimValue.i2 = 1;
        } else {
          /*document.getElementById(name + localAnimValue.i).style.zindex = "0"
          document.getElementById(name + localAnimValue.i).style.opacity = 1;*/
          document.getElementById(name + localAnimValue.i).style.visibility = "hidden"
          
          localAnimValue.i2 = 0;
          localAnimValue.i++;
          localAnimValue.i3 = localAnimValue.i + 1;
        }
        
        
        if (localAnimValue.i >= localAnimValue.L2) {
          localAnimValue.i = 0;
          localAnimValue.i2 = 0;
          localAnimValue.i3 = 1;
          document.getElementById(name + localAnimValue.i).style.visibility = "visible";
          clearInterval(p)
          clearInterval(this)
          lo()
        } else {
          //console.log("j")
          document.getElementById(name + localAnimValue.i).style.visibility = "visible";
          
        }
        //console.log(localAnimValue.i,document.getElementById(name + localAnimValue.i).style.zindex)
      } else {
        document.getElementById(name + localAnimValue.i).style.visibility = "visible"
      }
      
    }, train.show_speed - speed)
  }
}

// random important things


function train_S() {
  
  var i = {
    value: 0,
    value2: 0,
    value3: 0,
    value4: 0,
    random: 0.009
  }
  
  // Screen Shake
  setInterval(() => {
    if (i.value >= 1 && train.speed >= 10 && train.tension_up == true) {
      if (i.value2 >= 1) {
        i.value = 0;
        i.value2 = 0;
        i.random = Math.random() * 0.0001;
      }
      i.value2 += 0.00002; // playing cabing S time
      
      i.value3 = Math.random() * json_train["train option"]["train Shake intensity"][0];
      i.value3 -= i.value3 - i.value3 / 2;
      
      /*
      i.value4 = Math.random() * json_train["train option"]["train Shake intensity"][3];
      i.value4 -= json_train["train option"]["train Shake intensity"][3] / 3;
      
      document.getElementById('train element').style.transform = "rotate("+  i.value4  + "deg)";
      */
      document.getElementById('train element').style.left = i.value3 + "px";
      
      i.value3 = Math.random() * json_train["train option"]["train Shake intensity"][1];
      i.value3 -= i.value3 - i.value3 / 2;
      
      document.getElementById('train element').style.top = i.value3 + "px";
    } else if (train.speed >= 9 && train.speed <= 10){
      //document.getElementById('train element').style.transform = "rotate("+  0  + "deg)";
      document.getElementById('train element').style.left = "0px";
      document.getElementById('train element').style.top = "0px";
    }
    
    if (train.speed >= 10) {
      i.value += i.random;
    }
  }, 10)
}

var next_stopGUI_int = -20;

function next_stop(A, B, C) {
  // #next stop
  if (C == null) {
    
    if (B >= 99) {
      document.getElementById("center GUI").innerText = "the next stop is " + A + " in " + B.substr(0, 3) + " m";
    }
    if (B <= 10) {
      document.getElementById("center GUI").innerText = "the next stop is " + A + " in " + B.substr(0, 1) + " m";
    }
    if (B >= 10 && B <= 99) {
      document.getElementById("center GUI").innerText = "the next stop is " + A + " in " + B.substr(0, 2) + " m";
    }
    
    if (B <= 20) {
      document.getElementById("center GUI").style.border = "7px solid darkblue";
      document.getElementById("center GUI").style.backgroundColor = "darkblue";
    } else if (B <= 50) {
      train.in_station = true;
      document.getElementById("center GUI").style.border = "7px solid blue";
      document.getElementById("center GUI").style.backgroundColor = "blue";
    } else {
      train.in_station = false;
      document.getElementById("center GUI").style.border = "7px solid dodgerblue";
      document.getElementById("center GUI").style.backgroundColor = "dodgerblue";
    }
  }
  
  if (C == "int") {
    document.getElementById("center GUI").style.left = -100 + "px";
    var i = -700;
    
    var loop = setInterval(() => {
      if (i <= next_stopGUI_int) {
        i++;
      } else {
        clearInterval(loop);
      }
      document.getElementById("center GUI").style.left = i * 2 + "px";
    }, 0)
  }
  
  if (C == "out") {
    document.getElementById("center GUI").style.left = -50 + "px";
    var i = -50;
    
    var loop = setInterval(() => {
      if (i >= -900) {
        i--;
        
      } else {
        clearInterval(loop);
      }
      document.getElementById("center GUI").style.left = i * 2 + "px";
    }, 10)
  }
}

// loop thing

// train speed options
function loop2() {
  var loop2 = setInterval(() => {
    
    
    if (json_train["sound"]["train tration type"] == "default") {
    if (train.motor == "on") {
    
      if /* move */(train.power == "on" && train.tension_up == true && train.tension_dows == false && train.speed <= 119) {
        if (train.speed <= 15) {
          train.show_speed -= 0.3;
          train.speed += 0.3;
        } else if (train.speed <= 60) {
          train.show_speed -= 0.45;
          train.speed += 0.45;
        } else {
          train.show_speed -= 0.15;
          train.speed += 0.15
        }
      }
      
      if /* slow */ (train.tension_dows == true && train.tension_up == false && train.speed <= 119 && train.speed >= 1) {
        if (train.speed <= 15) {
          train.show_speed += 1.1;
          train.speed -= 1.1;
        } else {
          train.show_speed += 1.5;
          train.speed -= 1.5;
        }
      }
      
      if /* both  */(train.tension_dows == true && train.tension_up == true && train.speed <= 119 && train.speed >= 1) {
        if (train.speed <= 15) {
          train.show_speed += 0.9;
          train.speed -= 0.9;
        } else {
          train.show_speed += 0.7;
          train.speed -= 0.7;
        }
      }
      
      // fixe tration bug
      
      if (train.speed <= 1 && train.tension_up == true && train.tension_dows == false && train.door.on == true) {
        train.speed = 0;
        train.show_speed = 120;
        if (document.getElementById("tensiondows").src !== json_train_link + json_train.body.button["tension dows"][0] + ".png" && document.getElementById("tensionup").src !== json_train_link + json_train.body.button["tension up"][0] + ".png") {
          document.getElementById("tensiondows").src = json_train_link + json_train.body.button["tension dows"][0] + ".png";
          document.getElementById("tensionup").src = json_train_link + json_train.body.button["tension up"][0] + ".png";
        }
      }
      
      if (train.speed <= 1 && train.tension_up == false && train.tension_dows == false) {
        train.speed = 0;
        train.show_speed = 120;
        
        if (document.getElementById("tensiondows").src !== json_train_link + json_train.body.button["tension dows"][0] + ".png" && document.getElementById("tensionup").src !== json_train_link + json_train.body.button["tension up"][0] + ".png") {
          document.getElementById("tensiondows").src = json_train_link + json_train.body.button["tension dows"][0] + ".png";
          document.getElementById("tensionup").src = json_train_link + json_train.body.button["tension up"][0] + ".png";
        }    
        
        if (train.tension_dows == true) {
          train.tension_dows = false;
          if (document.getElementById("tensiondows").src !== json_train_link + json_train.body.button["tension dows"][0] + ".png") {
            document.getElementById("tensiondows").src = json_train_link + json_train.body.button["tension dows"][0] + ".png";
          }
        }
      }
      
      if (train.speed >= 1 && train.tension_up == false && train.tension_dows == false) {
        // the train lose speed 
        train.show_speed += 0.007;
        train.speed -= 0.007;
      }
    } else {
      train.speed = 0;
      train.show_speed = 120;
    }
    } else {
      error("error ! | train sound type invalid :" + json_train["train option"]["train tration type"]);
      clearInterval(loop2)
    }
  }, train.traction_speed)
}

// traject event and meter system
function loop3() {
  var i3 = 0;
  var i6 = 0;
  var i7 = 0;
  var traject_max = json_ligne.maps.trajet.length - 1;
  var random = {
    value: 0,
    value2: 20,
    T: 2,
    m: 0,
    GUI: false,
    C: 0
  }
  
  var R = setInterval(function() {
    //document.getElementById("m").innerText = "meter:"+game.meter;
    
    game.event.event = json_ligne.maps.trajet[i3]
    game.event.station = json_ligne.maps.trajet[i6];
    
    if (train.speed >= 1) {
      game.meter += train.speed * 0.0005;
    }
    
    if (train.moved == false || game.mini_maps == "false" && train.speed >= 1) {
      sessionStorage.setItem("meter", 15 + game.meter); // for the GUI
    } else {
      // console.log(game.mini_maps)
    }
    
    if (i3 <= traject_max) {
      if (json_ligne.maps.trajet[i3][2].distance <= game.meter) {
        
        // popup speed limit
        if (json_ligne.maps.trajet[i3][0] == "speed") {
          
          if (json_ligne.maps.trajet[i3][2].pre_release == true) {
            game.popup1.warning = true;
          } else {
            game.popup1.warning = false;
            document.getElementById("popup1").style.opacity = 1;
            document.getElementById("speed popup").style.opacity = 1;
          }
          
          if (json_ligne.maps.trajet[i3][2].hide == true) {
            document.getElementById("popup1").style.visibility = "hidden"
            document.getElementById("speed popup").style.visibility = "hidden"
            game.popup1.warning = false;
            popup(2)
          } else {
            document.getElementById("popup1").style.visibility = "visible";
            document.getElementById("speed popup").style.visibility = "visible"
            popup(1)
          }
          game.popup1.speed_limit = json_ligne.maps.trajet[i3][1];
          document.getElementById('speed popup').innerText = json_ligne.maps.trajet[i3][1];
        }
        
        i3++;
      }
    } else {
      // #end
      document.getElementById('end text').style.visibility = "visible";
    }
    
    
    if (i6 <= traject_max) {
      
      if /* manuel AWS */ (json_ligne.maps.trajet[i3][0] == "AWS" && game.meter >= 0.5) {
        if (random.C == 0 && train.AWS == false && json_ligne.maps.trajet[i3][2].distance - 5 <= game.meter && json_ligne.maps.trajet[i3][2].distance >= game.meter) {
          if (train.tension_up == true || train.tension_dows == true ) {
            train.AWS = true;
            
            /*
            game.sound.awsding.volume = 1;
            gamd.sound.awsding.currentTime = 0;
            */
          } else {
            new Audio("sounds/AWS-ding.mp3").play()
          }
          random.C = 1;
        }
        
        if (json_ligne.maps.trajet[i3][2].distance - 5 <= game.meter && json_ligne.maps.trajet[i3][2].distance >= game.meter) {
          
        } else {
          random.C = 0;
        }
      }
      
      if /* station sytem*/ (json_ligne.maps.trajet[i6][0] == "station") {
        
        if (json_ligne.maps.trajet[i6][2].distance - 150 <= game.meter && json_ligne.maps.trajet[i6][2].distance >= game.meter) {
          document.getElementById("center GUI").style.visibility = "visible";
        } else {
          document.getElementById("center GUI").style.visibility = "hidden";
        }
        
        if (json_ligne.maps.trajet[i6][2].distance - 10 <= game.meter) {
          random.GUI = false;
        }
        
        if (json_ligne.maps.trajet[i6][2].distance - 150 >= game.meter && json_ligne.maps.trajet[i6][2].distance - 155 <= game.meter) {
          if (random.GUI == false) {
            document.getElementById('center GUI').visibility = "visible";
            next_stop(null, null, "int");
            random.GUI = true;
          }
        }
        
        if (json_ligne.maps.trajet[i6][2].distance <= game.meter) {
          i6++;
        }
        
        next_stop(game.station.next_station, game.station.next_station_distance + "", null)
        game.station.next_station_distance = json_ligne.maps.trajet[i6][2].distance - 15 - game.meter;
        
        
        if (game.next_station !== json_ligne.maps.trajet[i6][1]) {
          game.station.next_station = json_ligne.maps.trajet[i6][1]
        }
        /*[2].distance*/
      } else {
        i6++;
      }
    }
    
    
    if /* passager system ( weird script ) */ (random.value <= 1 && random.value2 <= random.value3) {
      random.value = Math.random() * 350; // emply loop
    }
    if (train.door.on == true && train.in_station == true) {
      if (game.station.next_station !== game.station.last_station) {
        // when not last station
        if (random.value >= 1) {
          random.value--;
        }
        if (random.value <= 2 && random.value2 <= random.value3) {
          if (random.T >= 0.7) {
            if (train.passager <= train.max_passager) {
              train.passager++;
              onPassagerAdd()
            }
          } else {
            if (train.passager >= train.max_passager * 2) {
              train.passager -= 1;
            }
          }
          random.value2++;
          //console.log(train.passager + "/" + random.T)
          random.T = Math.random() * 2 // remove true/false as number
        }
      } else {
        // when last station 
        if (random.value >= 1) {
          random.value--;
        }
        if (random.value <= 2 && random.value2 <= random.value3) {
          if (train.passager >= 1) {
            train.passager -= 1;
          }
          random.value2++;
          //console.log(train.passager + "/" + random.T)
          random.T = Math.random() * 2 // remove true/false as number
        }
      }
    } else {
      random.value2 = 0; // reset max passager counter
      random.value3 = 25; // passager limit
    }
    if (train.door.on == true) {
      document.getElementById('n').innerText = "passagers :" + train.passager;
    }
    
    if (train.in_station == true && random.m == 0) {
      random.m = 1;
    }
  }, 0)
  
  var i5 = 0;
  var i4 = 0;
  
  setInterval(function() {
    if (i4 == 1 && game.popup1.warning == true) {
      i4 = 0;
      document.getElementById("popup1").style.opacity = 0.5
      document.getElementById("speed popup").style.opacity = 0.5;
    } else {
      i4 = 1;
      document.getElementById("popup1").style.opacity = 1
      document.getElementById("speed popup").style.opacity = 1;
    }
    
    // when the AWS it active
    
    if (train.AWS == true) {
      document.getElementById("aws").style.filter = "brightness(" + 200 + "%)";
      i5 += 1;
      if (i5 >= 7 && train.speed >= 1) {
        train.speed = 0;
        train.motor = "off";
        train.power = "off";
        
        document.getElementById("DNR 1").style.backgroundColor = "red";
        document.getElementById("DNR 2").style.backgroundColor = "red";

        train.show_speed = 120;
        train.tension_up = false;
        train.AWS = false;
      }
    }
    if (train.AWS == false) {
      i5 = 0;
      document.getElementById("aws").style.filter = "brightness(" + 100 + "%)";
    }
    
  }, 1000)
}
train.tension_up
// mini maps and speed value to text and AWS
function loop4() {
  setInterval(() => {
    train.speed2 = train.speed + "";
    game.meter2 = game.meter + "";
    
    if (train.speedMonitor.type == null) {
      error("null speed type found")
    }
    
    if (train.speedMonitor.type == 1) {
      if (train.speed >= 1) {
        if (train.speed >= 100) {
          document.getElementById("guispeed").innerText = train.speed2.substr(0, 3) + "km/h";
        } else if (train.speed <= 10) {
          document.getElementById("guispeed").innerText = train.speed2.substr(0, 1) + "km/h";
        } else if (train.speed >= 9) {
          document.getElementById("guispeed").innerText = train.speed2.substr(0, 2) + "km/h";
        }
      } else {
        document.getElementById("guispeed").innerText = "0km/h";
      }
    
      if (train.speed >= game.popup1.speed_limit + 3) {
        document.getElementById("guispeed").style.color = "#FF6C6C";
      } else {
        document.getElementById("guispeed").style.color = "white";
      }
    }
    
    if /* when max speed break */ (train.speed >= game.popup1.speed_limit + 3 && game.popup1.warning == false) {
      train.AWS = true;
    }
    
    if (game.mode.disable_AWS == true) {
      train.AWS = false;
    }
    
    if (train.in_station == true) {
      game.sound.stationAmbiance.volume = 0.8;
    } else {
      game.sound.stationAmbiance.volume = 0;
    }
    game.mini_maps = sessionStorage.getItem("mini Gui");
  }, 0)
}

function onPassagerAdd() {
  /*var value = 15;
  var i = setInterval(() => {
    if (value >= 17) {
      value -= 0.01;
      document.getElementById('n').style.fontSize = value + "px";
    } else {
      clearInterval(i);
    }
  },0)*/
}

function popup(onOff) {
  if (onOff == 1) {
    new Audio("sounds/ding.mp3").play()
  }
  
  if (onOff == 2) {
    
  }
}

// input

document.addEventListener('keydown', function(event) {
  if (event.key == "w") {
    document.getElementById("aws").onclick()
  }
  
  if (event.key == "d") {
     if (train.door.on == true) {
       document.getElementById("button_closedoors").onclick()
     } else {
       document.getElementById("button_opendoors").onclick()
     }
   }
   
  if (event.key == "ArrowUp") {
    document.getElementById("tensionup").onclick()
  }
  
  if (event.key == "ArrowDown") {
    document.getElementById("tensiondows").onclick()
  }
  
  if (event.key == "c") {
    document.getElementById("camera").onclick()
  }
});


// extrat

function $goto(redirect) {
  window.location = redirect;
  return window.location;
}

// command

function $Help() {
  console.log("‹ game command list: ›");
  console.log("");
  console.log("$tab(go to a file)")
  console.log("$meter(value / ”cur” = current train position)")
  console.log("$speed(value ( can't remove speed xd )")
  console.log("$duplicate(id)")
  console.log("$remove(id)")
  return "";
}

function $meter(value) {
  if (value == undefined) {
    return game.meter;
  } else {
    if (game.meter >= value) {
      return "can't go forward";
    } else {
      game.meter += value;
      return game.meter;
    }
  }
}

function $tab(p) {
  window.location = p;
}

function $speed(p) {
  train.speed += p;
  train.speed2 -= p;
  return game.speed;
}

function $duplicate(id) {
  document.body.appendChild(document.getElementById(id))
  return "done";
}

function $remove(id) {
  document.getElementById(id).remove()
  return "done"
}

function errorPng() {
  error("error :‹ | failed to load all images , probably due to a bad connection or your browser. please try again")
}

function errorAudio(name) {
  error("error :‹ | failed to load sounds "+name+" , probably due to a bad connection or your browser. please try again")
}

function error(A, redirect) {
  window.location = "Menu.html";
  alert("global error :‹ |"+A);
}