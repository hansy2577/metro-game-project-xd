 localStorage.setItem("can_scroll", false)
 localStorage.setItem("meter",0)
 
 let mainjson = null
 var rawFile = new XMLHttpRequest();
 var reload = 0;
 rawFile.open("get", "/main/assets/data.json", true);
 rawFile.onreadystatechange = function() {
   reload++;
   if (rawFile.readyState === 4) {
     var allText = rawFile.responseText;
   }
   if (reload == 3) {
     
     if (allText == "Error 404, file not found.") {
       alert("error ! | sorry no data asset found")
       document.body.remove()
     } else {
       mainjson = JSON.parse(allText);
       setbutton()
     }
   }
 }
 rawFile.send();
 
 var all_tab = ["game", "info", "setting", "tools","credit"];
 
 tab('game')
 

//localStorage.getItem('HTS canvas size')
  
 function tab(name) {
   for (var i = 0; i < all_tab.length; i++) {
     document.getElementById(all_tab[i]).style.visibility = 'hidden';
     document.getElementById('ligne').style.visibility = 'hidden';
     document.getElementById("B:"+all_tab[i]).style.filter = "brightness("+100+"%)";
     document.getElementById("B:"+all_tab[i]).style.scale = 0.8
   }
   document.getElementById("B:"+name).style.filter = "brightness("+50+"%)";
   document.getElementById("B:"+name).style.scale = 0.78

   
   document.getElementById(name).style.visibility = 'visible';
   

   if (name == "game") {
    document.getElementById('ligne').style.visibility = 'visible';
   }
 }
 
 function start() {
   localStorage.setItem("ligne select", document.getElementById("ligne").value);
   localStorage.setItem("map select", document.getElementById("map").value);
   localStorage.setItem("train select", document.getElementById("train").value);
   
   window.location = 'game.html';
 }
 
 function setbutton() {
   for (var i = 0; i < mainjson["all train"].length; i++) {
     var elemente = document.createElement("option");
     document.getElementById("train").appendChild(elemente);
     
     elemente.innerText = mainjson["all train"][i];
   }
   
   for (var i = 0; i < mainjson["all map"].length; i++) {
     var elemente = document.createElement("option");
     document.getElementById("map").appendChild(elemente);
     
     elemente.innerText = mainjson["all map"][i];
   }
   
   for (var i2 = 0; i2 < mainjson["all ligne"][document.getElementById("map").value].length; i2++) {
     var elemente = document.createElement("option");
     document.getElementById("ligne").appendChild(elemente);
     
     elemente.innerText = mainjson["all ligne"][document.getElementById("map").value][i2];
   }
   document.getElementById('bannier').src = "assets/Maps/" + document.getElementById("map").value + "/miniature.png"
 }
 
 function load_ligne(m) {
   if (m == "m" || m == "l") {
     document.getElementById('bannier').src = "assets/Maps/" + document.getElementById("map").value + "/miniature.png"
   }
   
   if (m == "l") {
     document.getElementById('description').innerText =  mainjson["description"][document.getElementById("ligne").value]
   }
   
   if (m == "m") {
     document.getElementById('description').innerText =  mainjson["description"][document.getElementById("map").value]
   }
   
   if (m == "t") {
     document.getElementById('bannier').src = "assets/Trains/" + document.getElementById("train").value + "/miniature.png"
     document.getElementById('description').innerText =  mainjson["description"][document.getElementById("train").value]
   }
   
  
   if (document.getElementById('description').innerText == "undefined") {
     document.getElementById('description').innerText = "..."
   }
   
   if (m !== "l") {
   document.getElementById("ligne").remove();
   
   var l = document.createElement("select");
   l.id = "ligne";
   l.style.backgroundColor = "white";
   l.style.position = "absolute";
   l.style.left = "340px";
   l.style.top = "55px";
   l.onchange = function () { load_ligne('l') }
   
   document.body.appendChild(l);
   
   if (document.getElementById("ligne").value !== null) {
     for (var i2 = 0; i2 < mainjson["all ligne"][document.getElementById("map").value].length; i2++) {
       var elemente = document.createElement("option");
       document.getElementById("ligne").appendChild(elemente);
       
       elemente.innerText = mainjson["all ligne"][document.getElementById("map").value][i2];
     }
   }
 }
 }
 
 //
 
function save(name) {
  

  if (name == "SA") {
    
    if (localStorage.getItem('HTS canvas size') !== null) {
      localStorage.setItem('HTS canvas size',document.getElementById('SA').value);
      //document.getElementById("BG").style.backgroundColor = document.getElementById('SA').value
      
      /*for (var i = 0; i < all_tab.length; i++) {
        document.getElementById("B:"+all_tab[i]).style.border = "4px solid "+document.getElementById('SA').value;
      }*/

    } else {
      localStorage.setItem('HTS canvas size',"1");
      //document.getElementById("BG").style.backgroundColor = "#C4C4C4";
    }
        //alert(localStorage.getItem('HTS canvas size'))
  }
  
  if (name == "SD") {
    
    if (localStorage.getItem('HTS setting custom BG2 color') !== null) {
      localStorage.setItem('HTS setting custom BG2 color',document.getElementById('SD').value);
    } else {
      localStorage.setItem('HTS setting custom BG2 color',"#C4C4C4");
    }
        //alert(localStorage.getItem('HTS canvas size'))
  }


  if (name == "SB") {
    console.log(localStorage.getItem('HTS setting timer mods'))
    localStorage.setItem('HTS setting timer mods',document.getElementById('SB').value);
    //alert(localStorage.getItem('HTS setting timer mods'))
  }
  
  if (name == "SC") {
    console.log(localStorage.getItem('HTS setting disable mini train'))
    localStorage.setItem('HTS setting disable mini train', document.getElementById('SC').value);
    //alert(localStorage.getItem('HTS setting timer mods'))
  }
}

function reset(name,A) {
  if (name == "SA") {
    localStorage.setItem('HTS canvas size',A);
    document.getElementById("SA").value = 1
    
    //document.getElementById("BG").style.backgroundColor = A;
    
   /* for (var i = 0; i < all_tab.length; i++) {
     document.getElementById("B:"+all_tab[i]).style.border = "4px solid "+A;
    } */
    //alert(localStorage.getItem('HTS canvas size'))
  }
  
  if (name == "SD") {
    localStorage.setItem('HTS setting custom BG2 color', A);
  }
}

document.getElementById('SA').value = localStorage.getItem('HTS canvas size');
document.getElementById('SB').value = localStorage.getItem('HTS setting timer mods');
document.getElementById('SC').value = localStorage.getItem('HTS setting disable mini train');
document.getElementById('SD').value = localStorage.getItem('HTS setting custom BG2 color');

save('SA');
save('SB');
save('SC');
save('SD');